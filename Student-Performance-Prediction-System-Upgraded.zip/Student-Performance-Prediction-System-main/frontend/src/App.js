import React, { useState, useEffect } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell
} from "recharts";
import {
  predictPerformance,
  fetchEvaluationMetrics,
  queryAIAgent
} from "./api";
import "./App.css";

function App() {
  const [activeTab, setActiveTab] = useState("predictor"); // 'predictor' | 'analytics'

  // Predictor state
  const [inputs, setInputs] = useState({
    raisedHands: "75",
    visitedResources: "80",
    discussion: "65",
    absences: "3"
  });
  const [predictionResult, setPredictionResult] = useState(null);
  const [predictLoading, setPredictLoading] = useState(false);
  const [predictError, setPredictError] = useState("");

  // AI Agent state
  const [question, setQuestion] = useState("");
  const [agentResponse, setAgentResponse] = useState(null);
  const [agentLoading, setAgentLoading] = useState(false);
  const [agentError, setAgentError] = useState("");
  const [showEvidence, setShowEvidence] = useState(false);

  // Model Evaluation Dashboard state
  const [evalData, setEvalData] = useState(null);
  const [selectedMetric, setSelectedMetric] = useState("accuracy"); // 'accuracy' | 'precision' | 'recall' | 'f1_score'
  const [selectedModelCM, setSelectedModelCM] = useState("Random Forest");

  useEffect(() => {
    // Load model evaluation data on mount
    fetchEvaluationMetrics()
      .then((data) => setEvalData(data))
      .catch((err) => console.log("Evaluation metrics loading deferred:", err));
  }, []);

  const handleInputChange = (e) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
  };

  const handlePredict = async (e) => {
    if (e) e.preventDefault();
    setPredictLoading(true);
    setPredictError("");

    try {
      const data = await predictPerformance({
        raisedHands: parseInt(inputs.raisedHands),
        visitedResources: parseInt(inputs.visitedResources),
        discussion: parseInt(inputs.discussion),
        absences: parseInt(inputs.absences)
      });
      setPredictionResult(data);
    } catch (err) {
      console.error(err);
      setPredictError(
        err.response?.data?.error || "Prediction request failed. Ensure backend server is running."
      );
    } finally {
      setPredictLoading(false);
    }
  };

  const handleAgentSubmit = async (customQ = null) => {
    const qToAsk = customQ || question;
    if (!qToAsk.trim()) return;

    setAgentLoading(true);
    setAgentError("");
    setQuestion(qToAsk);

    // Pass current inputs if relevant
    const features = {
      raisedHands: parseInt(inputs.raisedHands) || 0,
      visitedResources: parseInt(inputs.visitedResources) || 0,
      discussion: parseInt(inputs.discussion) || 0,
      absences: parseInt(inputs.absences) || 0
    };

    try {
      const res = await queryAIAgent(qToAsk, features);
      setAgentResponse(res);
      setShowEvidence(false);
    } catch (err) {
      console.error(err);
      setAgentError(
        err.response?.data?.error || "AI Agent request failed. Ensure backend is running."
      );
    } finally {
      setAgentLoading(false);
    }
  };

  const explainCurrentInputsWithAI = () => {
    setActiveTab("analytics");
    handleAgentSubmit("Explain the predictions for these input values.");
  };

  // Chart data for current prediction
  const predictionChartData = predictionResult?.predictions
    ? Object.entries(predictionResult.predictions).map(([name, label]) => ({
        name,
        label,
        value: label === "H" ? 1.0 : label === "M" ? 0.6 : 0.2
      }))
    : [];

  // Model comparison chart data from evaluation
  const comparisonChartData = evalData?.comparison
    ? evalData.comparison.map((c) => ({
        name: c.model,
        score: Math.round(c[selectedMetric] * 1000) / 10
      }))
    : [];

  const getMetricColor = (val) => {
    if (val === "H") return "#059669";
    if (val === "M") return "#D97706";
    return "#DC2626";
  };

  return (
    <div className="platform-container">
      {/* Header */}
      <header className="platform-header">
        <h1 className="platform-title">
          🎓 <span>Student Performance</span> Analytics Platform
        </h1>
        <p className="platform-subtitle">
          5 ML Classifiers &bull; Corrected Class Encoding &bull; Controlled LLM Analytics Agent &bull; 70/30 Holdout Evaluation
        </p>

        <div className="status-badge-container">
          <span className="badge badge-success">✅ Label Mapping Corrected (0:H, 1:L, 2:M)</span>
          <span className="badge badge-info">📊 144 Test Samples (30% Holdout Split)</span>
          <span className="badge badge-neutral">🤖 Controlled Tool-Calling Agent</span>
        </div>
      </header>

      {/* Tab Navigation */}
      <nav className="tabs-nav">
        <button
          className={`tab-btn ${activeTab === "predictor" ? "active" : ""}`}
          onClick={() => setActiveTab("predictor")}
        >
          🎯 Student Predictor
        </button>
        <button
          className={`tab-btn ${activeTab === "analytics" ? "active" : ""}`}
          onClick={() => setActiveTab("analytics")}
        >
          🤖 AI Analytics Agent & Benchmarks
        </button>
      </nav>

      {/* TAB 1: STUDENT PREDICTOR */}
      {activeTab === "predictor" && (
        <div>
          {/* Input Form Card */}
          <div className="card">
            <h2 className="card-title">📝 Student Behavioral & Activity Inputs</h2>
            <p className="input-hint" style={{ marginTop: "-0.5rem", marginBottom: "1rem" }}>
              Input features are validated against dataset boundaries (0 to 100). Absences reflect total term absence count.
            </p>

            {predictError && <div className="alert-error">⚠️ {predictError}</div>}

            <form onSubmit={handlePredict}>
              <div className="form-grid">
                <div className="input-field">
                  <label className="input-label">Raised Hands (0–100)</label>
                  <span className="input-hint">Classroom question participation</span>
                  <input
                    type="number"
                    name="raisedHands"
                    min="0"
                    max="100"
                    value={inputs.raisedHands}
                    onChange={handleInputChange}
                    className="input-control"
                    required
                  />
                </div>

                <div className="input-field">
                  <label className="input-label">Visited Resources (0–100)</label>
                  <span className="input-hint">Frequency of course portal views</span>
                  <input
                    type="number"
                    name="visitedResources"
                    min="0"
                    max="100"
                    value={inputs.visitedResources}
                    onChange={handleInputChange}
                    className="input-control"
                    required
                  />
                </div>

                <div className="input-field">
                  <label className="input-label">Discussion Group (0–100)</label>
                  <span className="input-hint">Peer forum and group participation</span>
                  <input
                    type="number"
                    name="discussion"
                    min="0"
                    max="100"
                    value={inputs.discussion}
                    onChange={handleInputChange}
                    className="input-control"
                    required
                  />
                </div>

                <div className="input-field">
                  <label className="input-label">Absence Days (0–100)</label>
                  <span className="input-hint">&lt;7 days: Under-7 | &ge;7 days: Above-7</span>
                  <input
                    type="number"
                    name="absences"
                    min="0"
                    max="100"
                    value={inputs.absences}
                    onChange={handleInputChange}
                    className="input-control"
                    required
                  />
                </div>
              </div>

              <div style={{ display: "flex", gap: "1rem", alignItems: "center" }}>
                <button type="submit" className="btn-primary" disabled={predictLoading}>
                  {predictLoading ? "Computing Predictions..." : "⚡ Run 5-Model Prediction"}
                </button>
                <button
                  type="button"
                  className="btn-outline"
                  onClick={() =>
                    setInputs({
                      raisedHands: "20",
                      visitedResources: "15",
                      discussion: "10",
                      absences: "12"
                    })
                  }
                >
                  Load At-Risk Profile
                </button>
                <button
                  type="button"
                  className="btn-outline"
                  onClick={() =>
                    setInputs({
                      raisedHands: "85",
                      visitedResources: "90",
                      discussion: "80",
                      absences: "2"
                    })
                  }
                >
                  Load High-Achiever Profile
                </button>
              </div>
            </form>
          </div>

          {/* Prediction Results Card */}
          {predictionResult && (
            <div className="card">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <h2 className="card-title">🎯 Multi-Model Predictions & Consensus</h2>
                <button className="btn-outline" onClick={explainCurrentInputsWithAI}>
                  💡 Explain with AI Agent &rarr;
                </button>
              </div>

              {/* Engagement Score */}
              <div className="engagement-header">
                <div>
                  <strong style={{ fontSize: "1.1rem" }}>Student Engagement Index: </strong>
                  <span style={{ fontSize: "1.3rem", fontWeight: 800, color: "var(--primary-dark)" }}>
                    {predictionResult.engagementScore} / 100
                  </span>
                </div>
                <span
                  className={`badge ${
                    predictionResult.engagementScore >= 70
                      ? "badge-success"
                      : predictionResult.engagementScore >= 40
                      ? "badge-info"
                      : "badge-neutral"
                  }`}
                >
                  {predictionResult.evaluation}
                </span>
              </div>

              <div className="progress-track">
                <div
                  className="progress-bar"
                  style={{ width: `${predictionResult.engagementScore}%` }}
                ></div>
              </div>

              {/* 5 Classifier Predictions */}
              <div className="model-predictions-grid">
                {Object.entries(predictionResult.predictions).map(([model, label]) => (
                  <div key={model} className="model-pred-card">
                    <div className="model-pred-name">{model}</div>
                    <div className={`model-pred-badge badge-${label.toLowerCase()}`}>
                      Class {label}
                    </div>
                    <div style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginTop: "0.25rem" }}>
                      {label === "H" ? "High (≥90)" : label === "M" ? "Medium (70-89)" : "Low (<70)"}
                    </div>
                  </div>
                ))}
              </div>

              {/* Recharts Model Agreement Chart */}
              <h3 style={{ fontSize: "1rem", color: "var(--text-muted)", marginTop: "1.5rem" }}>
                Predicted Performance Tier by Model
              </h3>
              <div style={{ width: "100%", height: 260 }}>
                <ResponsiveContainer>
                  <BarChart data={predictionChartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" interval={0} tick={{ fontSize: 11 }} />
                    <YAxis
                      domain={[0, 1.2]}
                      ticks={[0.2, 0.6, 1.0]}
                      tickFormatter={(v) => (v === 1.0 ? "H (High)" : v === 0.6 ? "M (Med)" : "L (Low)")}
                    />
                    <Tooltip
                      formatter={(val, name, item) => [
                        `Class ${item.payload.label} (${
                          item.payload.label === "H" ? "High" : item.payload.label === "M" ? "Medium" : "Low"
                        })`,
                        "Prediction"
                      ]}
                    />
                    <Bar dataKey="value" barSize={36} radius={[6, 6, 0, 0]}>
                      {predictionChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={getMetricColor(entry.label)} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: AI ANALYTICS AGENT & EVALUATION BENCHMARKS */}
      {activeTab === "analytics" && (
        <div>
          {/* Agent Question Box Card */}
          <div className="card">
            <h2 className="card-title">🤖 AI Analytics Agent with Controlled Tool Calling</h2>
            <p className="input-hint" style={{ marginTop: "-0.5rem", marginBottom: "1rem" }}>
              The agent uses 5 deterministic Python tools to inspect test-set metrics, distributions, and student features. All answers are grounded in empirical tool outputs with strict correlation vs. causation guardrails.
            </p>

            <div className="agent-input-container">
              <input
                type="text"
                className="agent-input"
                placeholder="Ask about model comparisons, metrics, dataset distributions, or input explanations..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleAgentSubmit()}
              />
              <button
                className="btn-primary"
                onClick={() => handleAgentSubmit()}
                disabled={agentLoading || !question.trim()}
              >
                {agentLoading ? "Executing Tools..." : "Ask Agent"}
              </button>
            </div>

            {/* Quick Suggestion Chips */}
            <div style={{ fontSize: "0.85rem", fontWeight: 600, color: "var(--text-muted)", marginBottom: "0.4rem" }}>
              Quick Questions:
            </div>
            <div className="suggestion-chips">
              {[
                "Which model performed best on the test set?",
                "Compare precision and recall across all models.",
                "What is the distribution of H, M and L in the dataset?",
                "Explain the predictions for these input values.",
                "Summarize student engagement patterns in the dataset."
              ].map((chip) => (
                <button
                  key={chip}
                  type="button"
                  className="chip-btn"
                  onClick={() => handleAgentSubmit(chip)}
                >
                  {chip}
                </button>
              ))}
            </div>

            {agentError && <div className="alert-error">⚠️ {agentError}</div>}

            {/* Agent Answer Panel */}
            {agentResponse && (
              <div>
                <div className="answer-card">
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                      <strong style={{ color: "var(--primary-dark)" }}>AI Analytics Response</strong>
                      {agentResponse.tool_calls?.[0] && (
                        <span className="badge badge-info">
                          Tool: {agentResponse.tool_calls[0].tool_name}
                        </span>
                      )}
                    </div>
                    <span className="latency-tag">⏱️ {agentResponse.latency_ms} ms</span>
                  </div>

                  <div className="answer-text" style={{ marginTop: "1rem" }}>
                    {agentResponse.answer}
                  </div>

                  {agentResponse.correlation_disclaimer_included && (
                    <div className="disclaimer-box">
                      <span>⚠️</span>
                      <div>
                        <strong>Scientific Guardrail:</strong> Correlation does not imply causation. Behavioral activity (resources, attendance, raised hands) reflects engagement patterns rather than independent causal drivers.
                      </div>
                    </div>
                  )}

                  {/* Toggle Evidence */}
                  {agentResponse.evidence && (
                    <div style={{ marginTop: "1.25rem" }}>
                      <button
                        className="btn-outline"
                        style={{ fontSize: "0.8rem", padding: "0.3rem 0.75rem" }}
                        onClick={() => setShowEvidence(!showEvidence)}
                      >
                        {showEvidence ? "Hide Raw Tool Evidence" : "Inspect Raw Tool Evidence"}
                      </button>

                      {showEvidence && (
                        <div className="evidence-box">
                          <div>
                            <strong>Tool Called:</strong> {agentResponse.tool_calls?.[0]?.tool_name}
                          </div>
                          <div>
                            <strong>Tool Latency:</strong> {agentResponse.tool_calls?.[0]?.latency_ms} ms
                          </div>
                          <div style={{ marginTop: "0.5rem" }}>
                            <strong>Raw Output:</strong>
                          </div>
                          <pre style={{ margin: 0 }}>
                            {JSON.stringify(agentResponse.evidence, null, 2)}
                          </pre>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Model Evaluation Dashboard */}
          <div className="card">
            <h2 className="card-title">📊 Model Evaluation Dashboard (Test-Set Holdout)</h2>
            <p className="input-hint" style={{ marginTop: "-0.5rem", marginBottom: "1.25rem" }}>
              Rigorous holdout evaluation on 144 test instances (30% split, random_state=42). Metrics are never derived from single predictions.
            </p>

            {/* KPI Cards */}
            <div className="kpi-grid">
              <div className="kpi-card">
                <div className="kpi-label">Test Set Size</div>
                <div className="kpi-value">{evalData?.metadata?.test_size || 144}</div>
                <span className="input-hint">30% of 480 students</span>
              </div>
              <div className="kpi-card">
                <div className="kpi-label">Top Model Accuracy</div>
                <div className="kpi-value">
                  {evalData?.comparison?.[0]
                    ? `${(evalData.comparison[0].accuracy * 100).toFixed(1)}%`
                    : "75.0%"}
                </div>
                <span className="input-hint">{evalData?.comparison?.[0]?.model || "MLP Classifier"}</span>
              </div>
              <div className="kpi-card">
                <div className="kpi-label">Class Encoding</div>
                <div className="kpi-value" style={{ fontSize: "1.2rem" }}>H:0, L:1, M:2</div>
                <span className="input-hint">Alphabetical LabelEncoder</span>
              </div>
              <div className="kpi-card">
                <div className="kpi-label">Total Models</div>
                <div className="kpi-value">5</div>
                <span className="input-hint">DT, RF, LR, Perc, MLP</span>
              </div>
            </div>

            {/* Metric Selector & Comparison Chart */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
              <h3 style={{ fontSize: "1.05rem", color: "var(--secondary)", margin: 0 }}>
                Model Comparison ({selectedMetric.toUpperCase()})
              </h3>
              <div style={{ display: "flex", gap: "0.5rem" }}>
                {["accuracy", "precision", "recall", "f1_score"].map((m) => (
                  <button
                    key={m}
                    className={`btn-outline ${selectedMetric === m ? "active" : ""}`}
                    style={{
                      background: selectedMetric === m ? "var(--primary)" : "transparent",
                      color: selectedMetric === m ? "white" : "var(--primary-dark)",
                      fontSize: "0.8rem",
                      padding: "0.35rem 0.75rem"
                    }}
                    onClick={() => setSelectedMetric(m)}
                  >
                    {m === "f1_score" ? "F1-Score" : m.charAt(0).toUpperCase() + m.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ width: "100%", height: 280 }}>
              <ResponsiveContainer>
                <BarChart data={comparisonChartData} margin={{ top: 10, right: 10, left: -10, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" interval={0} tick={{ fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tickFormatter={(v) => `${v}%`} />
                  <Tooltip formatter={(val) => [`${val}%`, selectedMetric.toUpperCase()]} />
                  <Bar dataKey="score" fill="#00BFA6" barSize={38} radius={[6, 6, 0, 0]}>
                    {comparisonChartData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={index === 0 ? "#009688" : index === comparisonChartData.length - 1 ? "#94A3B8" : "#00BFA6"}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Confusion Matrix Viewer */}
            <div style={{ marginTop: "2rem" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <h3 style={{ fontSize: "1.05rem", color: "var(--secondary)", margin: 0 }}>
                  Confusion Matrix Inspector
                </h3>
                <select
                  value={selectedModelCM}
                  onChange={(e) => setSelectedModelCM(e.target.value)}
                  style={{
                    padding: "0.4rem 0.8rem",
                    borderRadius: "6px",
                    border: "1px solid var(--border)",
                    fontSize: "0.85rem"
                  }}
                >
                  {evalData?.models &&
                    Object.keys(evalData.models).map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                </select>
              </div>

              {evalData?.models?.[selectedModelCM] && (
                <div style={{ marginTop: "1rem" }}>
                  <table className="confusion-table">
                    <thead>
                      <tr>
                        <th>Actual \ Predicted</th>
                        <th>Predicted H (High)</th>
                        <th>Predicted L (Low)</th>
                        <th>Predicted M (Medium)</th>
                        <th>Class Support</th>
                      </tr>
                    </thead>
                    <tbody>
                      {evalData.models[selectedModelCM].confusion_matrix.map((row, rowIdx) => {
                        const classLabel = rowIdx === 0 ? "Actual H (High)" : rowIdx === 1 ? "Actual L (Low)" : "Actual M (Medium)";
                        const classKey = rowIdx === 0 ? "H" : rowIdx === 1 ? "L" : "M";
                        const support = evalData.models[selectedModelCM].per_class[classKey]?.support || 0;
                        return (
                          <tr key={rowIdx}>
                            <td style={{ fontWeight: 700, background: "#F1F5F9" }}>{classLabel}</td>
                            {row.map((cell, colIdx) => (
                              <td
                                key={colIdx}
                                className={rowIdx === colIdx ? "cell-diagonal" : "cell-off"}
                              >
                                {cell}
                              </td>
                            ))}
                            <td style={{ fontWeight: 600 }}>{support}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>

                  {/* Per-class Metrics breakdown */}
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1rem", marginTop: "1rem" }}>
                    {["H", "L", "M"].map((clsKey) => {
                      const m = evalData.models[selectedModelCM].per_class[clsKey];
                      return (
                        <div key={clsKey} style={{ background: "#F8FAFC", padding: "0.75rem", borderRadius: "8px", border: "1px solid var(--border)" }}>
                          <strong>Class {clsKey} ({clsKey === "H" ? "High" : clsKey === "M" ? "Medium" : "Low"})</strong>
                          <div style={{ fontSize: "0.8rem", color: "var(--text-muted)", marginTop: "0.25rem" }}>
                            Precision: {(m?.precision * 100).toFixed(1)}% | Recall: {(m?.recall * 100).toFixed(1)}% | F1: {(m?.f1_score * 100).toFixed(1)}%
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
