# test_ml_correctness.py
import unittest
import os
import sys

_CURRENT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _CURRENT_DIR not in sys.path:
    sys.path.insert(0, _CURRENT_DIR)

try:
    import ml_engine
except ImportError:
    import importlib.util
    spec = importlib.util.spec_from_file_location('ml_engine', os.path.join(_CURRENT_DIR, 'ml_engine.py'))
    ml_engine = importlib.util.module_from_spec(spec)
    sys.modules['ml_engine'] = ml_engine
    spec.loader.exec_module(ml_engine)

class TestMLCorrectness(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry = ml_engine.ModelRegistry.get_instance(_CURRENT_DIR)

    def test_label_mapping_correctness(self):
        self.assertEqual(ml_engine.LABEL_MAP[0], 'H')
        self.assertEqual(ml_engine.LABEL_MAP[1], 'L')
        self.assertEqual(ml_engine.LABEL_MAP[2], 'M')
        self.assertEqual(ml_engine.INV_LABEL_MAP['H'], 0)
        self.assertEqual(ml_engine.INV_LABEL_MAP['L'], 1)
        self.assertEqual(ml_engine.INV_LABEL_MAP['M'], 2)

    def test_valid_input_validation(self):
        sample = {
            'raisedHands': 75,
            'visitedResources': 80,
            'discussion': 65,
            'absences': 3
        }
        res = ml_engine.validate_student_input(sample)
        self.assertEqual(res['raisedHands'], 75)
        self.assertEqual(res['visitedResources'], 80)
        self.assertEqual(res['discussion'], 65)
        self.assertEqual(res['absence_days'], 3)
        self.assertEqual(res['absence_encoded'], 1)

    def test_categorical_absence_input(self):
        sample_under = {'raisedHands': 50, 'visitedResources': 50, 'discussion': 50, 'absences': 'Under-7'}
        self.assertEqual(ml_engine.validate_student_input(sample_under)['absence_encoded'], 1)

        sample_above = {'raisedHands': 50, 'visitedResources': 50, 'discussion': 50, 'absences': 'Above-7'}
        self.assertEqual(ml_engine.validate_student_input(sample_above)['absence_encoded'], 0)

    def test_missing_field_rejection(self):
        incomplete = {'raisedHands': 50, 'visitedResources': 50}
        with self.assertRaises(ValueError):
            ml_engine.validate_student_input(incomplete)

    def test_out_of_range_rejection(self):
        cases = [
            {'raisedHands': -5, 'visitedResources': 50, 'discussion': 50, 'absences': 2},
            {'raisedHands': 150, 'visitedResources': 50, 'discussion': 50, 'absences': 2},
            {'raisedHands': 50, 'visitedResources': -1, 'discussion': 50, 'absences': 2},
            {'raisedHands': 50, 'visitedResources': 50, 'discussion': 105, 'absences': 2},
            {'raisedHands': 50, 'visitedResources': 50, 'discussion': 50, 'absences': -3}
        ]
        for c in cases:
            with self.assertRaises(ValueError):
                ml_engine.validate_student_input(c)

    def test_high_engagement_prediction(self):
        sample = {'raisedHands': 90, 'visitedResources': 95, 'discussion': 85, 'absences': 1}
        pred = self.registry.predict_student(sample)
        self.assertGreaterEqual(pred['engagementScore'], 70)
        self.assertEqual(pred['evaluation'], 'Excellent & Highly Active')
        self.assertEqual(len(pred['predictions']), 5)
        self.assertIn('Random Forest', pred['predictions'])
        self.assertIn('MLP Classifier', pred['predictions'])

    def test_low_engagement_prediction(self):
        sample = {'raisedHands': 8, 'visitedResources': 10, 'discussion': 12, 'absences': 16}
        pred = self.registry.predict_student(sample)
        self.assertLess(pred['engagementScore'], 40)
        self.assertEqual(pred['evaluation'], 'Needs Improvement')
        self.assertIn(pred['predictions']['Random Forest'], ['L', 'M'])

if __name__ == '__main__':
    unittest.main()
