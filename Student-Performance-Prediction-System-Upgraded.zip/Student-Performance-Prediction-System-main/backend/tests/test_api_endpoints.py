# test_api_endpoints.py
import unittest
import os
import sys
import json

_CURRENT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _CURRENT_DIR not in sys.path:
    sys.path.insert(0, _CURRENT_DIR)

try:
    import app as app_module
except ImportError:
    import importlib.util
    spec = importlib.util.spec_from_file_location('app', os.path.join(_CURRENT_DIR, 'app.py'))
    app_module = importlib.util.module_from_spec(spec)
    sys.modules['app'] = app_module
    spec.loader.exec_module(app_module)

class TestAPIEndpoints(unittest.TestCase):
    def test_predict_endpoint_success(self):
        """Test /predict handler with valid input."""
        payload = {
            'raisedHands': 75,
            'visitedResources': 80,
            'discussion': 70,
            'absences': 3
        }
        res, status = app_module.handle_predict(payload)
        self.assertEqual(status, 200)
        self.assertIn('predictions', res)
        self.assertIn('engagementScore', res)
        self.assertIn('evaluation', res)
        self.assertIn('validatedInput', res)
        self.assertEqual(len(res['predictions']), 5)
        self.assertIn(res['predictions']['Random Forest'], ['H', 'M', 'L'])

    def test_predict_endpoint_invalid_input(self):
        """Test /predict handler rejects missing fields and out-of-range values."""
        # Missing field
        res, status = app_module.handle_predict({'raisedHands': 50})
        self.assertEqual(status, 400)
        self.assertIn('error', res)

        # Out of range
        res, status = app_module.handle_predict({
            'raisedHands': 150,
            'visitedResources': 50,
            'discussion': 50,
            'absences': 2
        })
        self.assertEqual(status, 400)
        self.assertIn('error', res)

    def test_evaluation_endpoint(self):
        """Test /api/evaluation handler returns 5 models and methodology."""
        res, status = app_module.handle_evaluation()
        self.assertEqual(status, 200)
        self.assertIn('metadata', res)
        self.assertIn('models', res)
        self.assertIn('comparison', res)
        self.assertEqual(len(res['models']), 5)
        self.assertEqual(len(res['comparison']), 5)
        self.assertEqual(res['metadata']['test_size'], 144)

    def test_dataset_summary_endpoint(self):
        """Test /api/dataset/summary handler returns distribution and engagement."""
        res, status = app_module.handle_dataset_summary()
        self.assertEqual(status, 200)
        self.assertIn('distribution', res)
        self.assertIn('engagement', res)
        self.assertEqual(res['distribution']['total_dataset_records'], 480)

    def test_agent_query_endpoint(self):
        """Test /api/agent/query handler with valid question."""
        payload = {
            'question': 'Which model performed best on the test set?'
        }
        res, status = app_module.handle_agent_query(payload)
        self.assertEqual(status, 200)
        self.assertIn('answer', res)
        self.assertIn('tool_calls', res)
        self.assertIn('latency_ms', res)
        self.assertGreater(len(res['tool_calls']), 0)
        self.assertEqual(res['tool_calls'][0]['tool_name'], 'compare_models')

    def test_agent_query_empty_rejection(self):
        """Test /api/agent/query handler rejects empty question with 400."""
        res, status = app_module.handle_agent_query({'question': '   '})
        self.assertEqual(status, 400)
        self.assertIn('error', res)

    def test_health_endpoint(self):
        """Test /api/health returns healthy and label_mapping_corrected."""
        res, status = app_module.handle_health()
        self.assertEqual(status, 200)
        self.assertEqual(res['status'], 'healthy')
        self.assertTrue(res['label_mapping_corrected'])
        self.assertEqual(res['class_mapping'][1], 'L')
        self.assertEqual(res['class_mapping'][2], 'M')

if __name__ == '__main__':
    unittest.main()
