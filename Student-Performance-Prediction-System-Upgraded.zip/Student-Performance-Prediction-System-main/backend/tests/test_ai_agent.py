# test_ai_agent.py
import unittest
import os
import sys

_CURRENT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _CURRENT_DIR not in sys.path:
    sys.path.insert(0, _CURRENT_DIR)

try:
    import agent as agent_module
except ImportError:
    import importlib.util
    spec = importlib.util.spec_from_file_location('agent', os.path.join(_CURRENT_DIR, 'agent.py'))
    agent_module = importlib.util.module_from_spec(spec)
    sys.modules['agent'] = agent_module
    spec.loader.exec_module(agent_module)

class TestAIAgent(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.agent = agent_module.AIAnalyticsAgent()

    def test_tool_selection_compare_models(self):
        """Verify query routing selects compare_models."""
        queries = [
            'Which model performed best on the test set?',
            'Compare precision and recall across all models.',
            'What is the ranking of models by accuracy?'
        ]
        for q in queries:
            tool, kwargs, valid, _ = self.agent.route_query(q)
            self.assertTrue(valid, f"Query failed routing: {q}")
            self.assertEqual(tool, 'compare_models')

    def test_tool_selection_distribution(self):
        """Verify query routing selects get_prediction_distribution."""
        queries = [
            'What is the distribution of H, M and L in the dataset?',
            'How many students belong to class H, M, and L?',
            'What is the class balance of the dataset?'
        ]
        for q in queries:
            tool, kwargs, valid, _ = self.agent.route_query(q)
            self.assertTrue(valid, f"Query failed routing: {q}")
            self.assertEqual(tool, 'get_prediction_distribution')

    def test_tool_selection_engagement_summary(self):
        """Verify query routing selects get_engagement_summary."""
        queries = [
            'Summarize student engagement patterns.',
            'How does attendance and absences relate to student performance?',
            'Show the behavioral indicators and raised hands across classes.'
        ]
        for q in queries:
            tool, kwargs, valid, _ = self.agent.route_query(q)
            self.assertTrue(valid, f"Query failed routing: {q}")
            self.assertEqual(tool, 'get_engagement_summary')

    def test_tool_selection_model_metrics(self):
        """Verify query routing selects get_model_metrics for single model queries."""
        queries = [
            ('How did Random Forest perform on the test set?', 'random forest'),
            ('Show the confusion matrix and metrics for Decision Tree', 'decision tree'),
            ('What is the precision and recall of Logistic Regression?', 'logistic regression')
        ]
        for q, expected_model in queries:
            tool, kwargs, valid, _ = self.agent.route_query(q)
            self.assertTrue(valid, f"Query failed routing: {q}")
            self.assertEqual(tool, 'get_model_metrics')
            self.assertEqual(kwargs['model_name'], expected_model)

    def test_tool_selection_analyze_student(self):
        """Verify query routing selects analyze_student_input."""
        q = 'Explain the predictions for these input values.'
        features = {'raisedHands': 85, 'visitedResources': 90, 'discussion': 75, 'absences': 2}
        tool, kwargs, valid, _ = self.agent.route_query(q, features)
        self.assertTrue(valid)
        self.assertEqual(tool, 'analyze_student_input')
        self.assertEqual(kwargs['features'], features)

    def test_invalid_and_out_of_scope_questions(self):
        """Verify out-of-scope or nonsensical queries are cleanly rejected."""
        invalid_queries = [
            'What is the capital of France?',
            'Write a poem about dogs',
            'Predict tomorrow stock price of Apple',
            ''
        ]
        for q in invalid_queries:
            res = self.agent.answer_query(q)
            self.assertEqual(res['status'], 'rejected')
            self.assertEqual(len(res['tool_calls']), 0)
            ans = res['answer'].lower()
            self.assertTrue(
                'outside the scope' in ans or 'cannot be empty' in ans or 'try asking' in ans,
                f"Unexpected rejection text: {res['answer']}"
            )

    def test_latency_tracking(self):
        """Verify execution time is recorded in milliseconds and is positive."""
        res = self.agent.answer_query('Which model performed best on the test set?')
        self.assertGreater(res['latency_ms'], 0.0)
        self.assertLess(res['latency_ms'], 5000.0)
        self.assertEqual(len(res['tool_calls']), 1)
        self.assertGreater(res['tool_calls'][0]['latency_ms'], 0.0)

    def test_privacy_and_no_pii_logging(self):
        """Verify audit logs do not store student PII or raw student data."""
        features = {
            'student_name': 'Secret Alice',
            'email': 'alice@example.com',
            'raisedHands': 70,
            'visitedResources': 75,
            'discussion': 60,
            'absences': 3
        }
        res = self.agent.answer_query('Analyze these input values for the student.', features)
        self.assertEqual(res['status'], 'success')

        for entry in self.agent.audit_log:
            self.assertNotIn('Secret Alice', str(entry))
            self.assertNotIn('alice@example.com', str(entry))
            self.assertIn('tool_name', entry)
            self.assertIn('latency_ms', entry)
            self.assertIn('status', entry)

    def test_correlation_causation_disclaimer(self):
        """Verify agent includes correlation != causation disclaimer on engagement summaries."""
        res = self.agent.answer_query('Summarize student engagement patterns in the dataset.')
        self.assertTrue(res['correlation_disclaimer_included'])
        self.assertIn('causation', res['answer'].lower())

if __name__ == '__main__':
    unittest.main()
