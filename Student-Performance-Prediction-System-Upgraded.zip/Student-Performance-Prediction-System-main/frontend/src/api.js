import axios from "axios";

const API_BASE_URL = process.env.REACT_APP_API_URL || "http://127.0.0.1:5000";

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json"
  },
  timeout: 10000
});

export const predictPerformance = async (data) => {
  const response = await apiClient.post("/predict", data);
  return response.data;
};

export const fetchEvaluationMetrics = async () => {
  const response = await apiClient.get("/api/evaluation");
  return response.data;
};

export const fetchDatasetSummary = async () => {
  const response = await apiClient.get("/api/dataset/summary");
  return response.data;
};

export const queryAIAgent = async (question, features = null) => {
  const payload = { question };
  if (features) {
    payload.features = features;
  }
  const response = await apiClient.post("/api/agent/query", payload);
  return response.data;
};

export const checkHealth = async () => {
  const response = await apiClient.get("/api/health");
  return response.data;
};

export default apiClient;
