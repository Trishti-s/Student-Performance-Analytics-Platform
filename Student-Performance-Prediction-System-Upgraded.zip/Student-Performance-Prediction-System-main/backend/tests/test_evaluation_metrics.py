# test_evaluation_metrics.py
import unittest
import os
import sys
import json

_CURRENT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _CURRENT_DIR not in sys.path:
    sys.path.insert(0, _CURRENT_DIR)

try:
    import ml_engine
except ImportError:
    import importlib.util
    spec = importlib.util.spec_from_file_location('ml_engine', os.path.join(_CURRENT_DIR, 'ml_engine.py'))
    ml_engine = importlib.util.module_from_spec(spec)
    sys.modules['ml_engine'] = ml_engine
    spec.loader.exec_module(ml_engine)

class TestEvaluationMetrics(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry = ml_engine.ModelRegistry.get_instance(_CURRENT_DIR)
        cls.eval_data = cls.registry.evaluation_data

    def test_evaluation_file_exists(self):
        """Verify model_evaluation.json exists and is valid JSON."""
        self.assertIsNotNone(self.eval_data)
        self.assertIn('metadata', self.eval_data)
        self.assertIn('models', self.eval_data)
        self.assertIn('comparison', self.eval_data)

    def test_test_set_size_and_methodology(self):
        """Verify test set size is 144 (30% of 480) and methodology is documented."""
        meta = self.eval_data['metadata']
        self.assertEqual(meta['total_samples'], 480)
        self.assertEqual(meta['train_size'], 336)
        self.assertEqual(meta['test_size'], 144)
        self.assertEqual(meta['random_state'], 42)
        self.assertIn('evaluation_methodology', meta)
        self.assertTrue(len(meta['evaluation_methodology']) > 20)

    def test_all_five_models_evaluated(self):
        """Verify all 5 classifiers are present in evaluation results."""
        expected = [
            'Decision Tree',
            'Random Forest',
            'Logistic Regression',
            'Perceptron',
            'MLP Classifier'
        ]
        models = self.eval_data['models']
        for name in expected:
            self.assertIn(name, models, f'Missing model: {name}')

    def test_metrics_ranges(self):
        """Verify accuracy, precision, recall, and F1 are valid numbers in [0, 1]."""
        for name, metrics in self.eval_data['models'].items():
            for m in ['accuracy', 'precision_weighted', 'recall_weighted', 'f1_weighted', 'precision_macro', 'recall_macro', 'f1_macro']:
                val = metrics[m]
                self.assertIsInstance(val, (int, float))
                self.assertGreaterEqual(val, 0.0, f'{name} {m} below 0')
                self.assertLessEqual(val, 1.0, f'{name} {m} above 1')

    def test_confusion_matrices(self):
        """Verify confusion matrices are 3x3 with non-negative integers."""
        for name, metrics in self.eval_data['models'].items():
            cm = metrics['confusion_matrix']
            self.assertEqual(len(cm), 3)
            total_cm = 0
            for row in cm:
                self.assertEqual(len(row), 3)
                for cell in row:
                    self.assertGreaterEqual(cell, 0)
                    total_cm += cell
            self.assertEqual(total_cm, 144, f'{name} confusion matrix total != 144 test instances')

    def test_comparison_list_sorting(self):
        """Verify model comparison is ranked by accuracy."""
        comp = self.eval_data['comparison']
        self.assertEqual(len(comp), 5)
        for i in range(len(comp) - 1):
            self.assertGreaterEqual(comp[i]['accuracy'], comp[i+1]['accuracy'])

if __name__ == '__main__':
    unittest.main()
